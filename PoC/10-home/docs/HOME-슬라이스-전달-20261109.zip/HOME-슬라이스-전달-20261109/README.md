# HOME 자료 전달 요청 — 슬라이스 형식 v1 (2026-11-09)

the-housing 상황판(the-housing.vercel.app)은 HOME 자료로 원장과 화면 수치를 HOME 과 같게 맞춥니다. 지금까지는 DB 덤프(1.9 GB)를 받아 손으로 옮겼습니다. 앞으로는 **2026-10-22 이후 바뀐 자료만 JSON 슬라이스 묶음으로** 보내 주시면, 저희가 명령 한 번으로 반영합니다.

- 슬라이스 = 저희가 실제로 쓰는 HOME 원천 31종(`home_revision` kind 25 · 작은 표 4 · 쌓이는 표 2) 중 쓰는 칸만 남긴 것.
- 크기: 10-22 하루치 변경분 기준 약 7 MB(압축 1.6 MB).
- 자세한 규칙은 `명세-HOME-데이터셋-슬라이스.md` 에 있습니다.

## 1. 보내 주실 것

`home-slices-<until>.zip` 하나. 안의 구성은 아래와 같습니다.

```text
manifest.json     형식·since·until·파일 sha256·현재 판 요약(건수·해시)
slices/           31개 JSON (변경이 없어도 [] 로)
api/              HOME API 응답 10종
golden/           정답 대조용 HOME API 응답
web/              화면 계산 JS 4개
```

## 2. 만드는 법

준비물: `psql`(PostgreSQL 12 이상), Python 3(표준 라이브러리만, 저희는 3.14 에서 확인). 이 폴더를 그대로 두고 이 폴더 안에서 실행합니다(`tools/`·`schemas/` 위치가 바뀌면 안 됩니다).

```bash
# ① DB 에서 내보내기 — 한 READ ONLY 트랜잭션. export/ 가 생깁니다(실명 포함: HOME 밖으로 보내지 마세요)
psql "$HOME_DB_URL" -v since='2026-10-22 00:00:00+09' -v commit=<HOME 앱 커밋> -f export.sql

# ② 같은 시점의 HOME API 응답·프런트 JS 를 fetched/ 에 저장
#    fetched/api/<저장 이름>, fetched/golden/<저장 이름>, fetched/web/<저장 이름>
#    목록(요청 경로·쿼리·저장 이름)은 명세 6절 표, 정확한 목록은 schemas/home-slices/slices.json 의 api·golden·web
#    받은 시각을 남기려면 fetched/fetched.json 에 {"api/<저장 이름>": "<받은 시각>"} 로 적어 주세요(선택)

# ③ 봉인 — 쓰는 칸만 자르고, 글 속 담당자 이름·사유를 지우고, 키 검사·sha256 을 적습니다
python3 tools/ledger/home-slice.py seal --export export --api fetched --out home-slices-<until>

# ④ home-slices-<until> 폴더를 zip 으로 묶어 보내 주세요(export/ 는 보내지 않습니다)
```

`export.sql` 은 `python3 tools/ledger/home-slice.py sql` 로 다시 만들 수 있습니다(`schemas/home-slices/slices.json` 에서 만듭니다).

## 3. 지켜 주실 것

| 항목 | 내용 |
|---|---|
| since | **첫 묶음은 `2026-10-22 00:00:00+09`**. 다음부터는 지난 묶음의 `until` 보다 조금(예: 1시간) 앞. 겹친 구간은 저희가 알아서 합칩니다 |
| 같은 시점 | `api/`·`golden/`·`web/` 은 ① 직후 같은 시점에 받아 주세요. 시간이 지나면 수집·담당자 입력으로 값이 달라져 정답 대조가 어긋납니다. 가능하면 수집 worker 를 멈춘 상태에서 해 주세요 |
| 실명 | `export/` 에는 담당자 이름·사유가 있습니다. **봉인한 묶음만** 보내 주세요. 봉인이 이름·사유를 지우지 못하는 경우에는 스스로 멈춥니다 |
| 키 | API 키·비밀번호가 글에 섞여 있으면 봉인이 멈춥니다(값은 출력하지 않음) |
| 표·칸 추가 | HOME 쪽에서 표·kind·칸 이름이 바뀌면 미리 알려 주세요. 저희 쪽 반영이 멈춥니다 |

## 4. 저희 쪽에서 멈추는 경우

아래 중 하나라도 걸리면 저희는 반영하지 않고 다시 요청드립니다.

- 파일 sha256·행 수가 manifest 와 다를 때
- 합친 결과의 kind 별 건수·해시가 `manifest.current` 와 다를 때(빠진 행)
- since 가 저희가 가진 최신 판(2026-10-22 22:35 공유본)보다 늦어 빈 구간이 생길 때
- 정의에 없는 원천·칸이 들어 있을 때
- 변환 결과에 사업 id 충돌·분류 불가 사업이 생길 때
- 정답 대조(HOME 화면 수치와 저희 수치)가 다를 때

## 5. 부탁(선택)

`stage_evidence`·`evidence_bridge`·`project_profile`·`policy_delivery_plan` 4종(약 2,050행)은 글 속 담당자 이름·사유를 지우는 결과가 판 전체 목록에 따라 달라집니다. 그래서 변경분이 아니라 매번 전체를 받습니다. 원천 글(`basis` 등)에 이름·사유를 넣지 않는 방식으로 바꿀 수 있으면 이 4종도 변경분만 받을 수 있습니다.

## 6. 아직 확인 못 한 것

- `export.sql` 은 저희에게 HOME DB 가 없어 **실제 DB 에서 돌려 보지 못했습니다**. 같은 내용을 덤프에서 만들어 봉인 결과가 같은 것까지 확인했습니다. 특히 jsonpath 문법과 psql `\o` 출력은 확인하지 못했습니다. 처음 돌릴 때 오류가 나면 오류 문구를 그대로 알려 주세요.
- 저희가 확인한 것: 10-22 06:23 판 + 10-22 이후 변경분 = 10-22 22:35 판(바이트 동일), 그 판으로 저희 원장·화면 자료 177개 파일이 원본 판과 바이트 동일, HOME 정답 대조 51건 통과.

## 7. 이 폴더의 파일

| 파일 | 설명 |
|---|---|
| `README.md` | 이 안내 |
| `전달문.txt` | 대화방에 붙여 넣을 짧은 글 |
| `명세-HOME-데이터셋-슬라이스.md` | 형식 명세(슬라이스 표·manifest 규칙·SQL 요지·API 목록·멈춤 조건) |
| `export.sql` | ① 에서 쓰는 psql 스크립트 |
| `tools/ledger/home-slice.py` | `sql`·`seal`(HOME 쪽), `make`·`apply`(저희 쪽) |
| `tools/ledger/home-dump.py` | 직렬화·키 검사 함수(home-slice.py 가 불러 씀) |
| `schemas/home-slices/slices.json` | 슬라이스·칸·변경분 규칙·API 목록 정의(정본) |
| `schemas/home-slices/manifest.schema.json` | manifest JSON Schema |
| `schemas/home-slices/template/` | 묶음 틀(가짜 값 예시 1행씩) |
| `SHA256SUMS.txt` | 파일 무결성 |
