-- home-slice.py sql 이 slices.json 에서 만든 것. 사용: psql "$HOME_DB_URL" -v since='2026-10-22 00:00:00+09' -v commit=<HOME 소스 커밋> -f export.sql
-- 결과: export/ 폴더(실명 포함 — HOME 밖으로 내지 않는다) → python3 tools/ledger/home-slice.py seal --export export --out <패키지>
\set ON_ERROR_STOP on
\pset format unaligned
\pset tuples_only on
\pset pager off
\! mkdir -p export/rows
BEGIN TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY;
SET LOCAL TimeZone = 'UTC';
\o export/meta.json
SELECT json_build_object('since', :'since'::timestamptz::text, 'until', now()::text, 'source_commit', :'commit', 'alembic_version', (SELECT version_num FROM alembic_version LIMIT 1), 'dump_sha256', NULL);
\o export/rows/home_revision.jsonl
SELECT json_build_object('entity_id', entity_id, 'kind', kind, 'source_id', source_id, 'revision_no', revision_no, 'recorded_at', recorded_at::text, 'payload_hash', payload_hash, 'batch_id', batch_id, 'payload', payload) FROM home_revision
  WHERE superseded_at IS NULL AND kind = ANY(ARRAY['policy', 'policy_delivery_plan', 'project', 'project_report', 'stage_evidence', 'lh_completion_plan', 'lh_notice', 'notice', 'gh_notice', 'statistic', 'area_stat', 'unsold', 'district', 'block_location', 'project_location', 'collection_link', 'municipality', 'policy_municipality', 'evidence_bridge', 'lh_movein_plan', 'document_evidence', 'delivery_setting', 'execution_schedule', 'project_profile', 'mapping_decision'])
    AND (recorded_at > :'since'::timestamptz OR kind = ANY(ARRAY['policy_delivery_plan', 'stage_evidence', 'evidence_bridge', 'project_profile']))
  ORDER BY kind, entity_id COLLATE "C", revision_no;
\o export/current.jsonl
SELECT json_build_object('kind', kind, 'count', count(*), 'digest', encode(sha256(convert_to(string_agg(entity_id || ':' || revision_no, E'\n' ORDER BY entity_id COLLATE "C"), 'UTF8')), 'hex'))
  FROM home_revision WHERE superseded_at IS NULL AND kind = ANY(ARRAY['policy', 'policy_delivery_plan', 'project', 'project_report', 'stage_evidence', 'lh_completion_plan', 'lh_notice', 'notice', 'gh_notice', 'statistic', 'area_stat', 'unsold', 'district', 'block_location', 'project_location', 'collection_link', 'municipality', 'policy_municipality', 'evidence_bridge', 'lh_movein_plan', 'document_evidence', 'delivery_setting', 'execution_schedule', 'project_profile', 'mapping_decision']) GROUP BY kind ORDER BY kind;
\o export/removed.jsonl
SELECT json_build_object('kind', r.kind, 'entity_id', r.entity_id) FROM (SELECT DISTINCT kind, entity_id FROM home_revision
  WHERE kind = ANY(ARRAY['policy', 'policy_delivery_plan', 'project', 'project_report', 'stage_evidence', 'lh_completion_plan', 'lh_notice', 'notice', 'gh_notice', 'statistic', 'area_stat', 'unsold', 'district', 'block_location', 'project_location', 'collection_link', 'municipality', 'policy_municipality', 'evidence_bridge', 'lh_movein_plan', 'document_evidence', 'delivery_setting', 'execution_schedule', 'project_profile', 'mapping_decision']) AND superseded_at > :'since'::timestamptz) r
  WHERE NOT EXISTS (SELECT 1 FROM home_revision c WHERE c.kind = r.kind AND c.entity_id = r.entity_id AND c.superseded_at IS NULL)
  ORDER BY r.kind, r.entity_id COLLATE "C";
\o export/terms.jsonl
WITH docs AS (SELECT payload::jsonb AS d FROM home_revision WHERE superseded_at IS NULL AND kind = ANY(ARRAY['policy', 'policy_delivery_plan', 'policy_event', 'project', 'project_report', 'stage_evidence', 'sequence_review', 'lh_completion_plan', 'lh_notice', 'notice', 'gh_notice', 'statistic', 'area_stat', 'unsold', 'district', 'block_location', 'project_location', 'plan_notice', 'collection_link', 'municipality', 'policy_municipality', 'evidence_bridge', 'lh_movein_plan', 'document_evidence', 'delivery_setting', 'execution_schedule', 'project_profile', 'mapping_decision'])
  UNION ALL SELECT before::jsonb FROM home_audit WHERE action LIKE '%\_REVIEW' UNION ALL SELECT after::jsonb FROM home_audit WHERE action LIKE '%\_REVIEW'
  UNION ALL SELECT stats::jsonb FROM home_batch),
  t AS (SELECT DISTINCT k.key, v #>> '{}' AS value FROM docs, (VALUES ('actor'), ('reason'), ('change_reason')) AS k(key),
    LATERAL jsonb_path_query(d, ('lax $.**.' || k.key)::jsonpath) AS v WHERE jsonb_typeof(v) = 'string')
SELECT json_build_object('key', key, 'value', value) FROM t ORDER BY key, value COLLATE "C";
\o export/rows/home_project.jsonl
SELECT row_to_json(t) FROM (SELECT id, name FROM home_project) t ORDER BY id COLLATE "C";
\o export/rows/home_identity_alias.jsonl
SELECT row_to_json(t) FROM (SELECT id, match_rule, project_id, source_entity_id, unit_comparison FROM home_identity_alias) t ORDER BY id COLLATE "C";
\o export/rows/home_mapping.jsonl
SELECT row_to_json(t) FROM (SELECT basis, evidence_url, id, policy_id, program_id, project_id, status FROM home_mapping) t ORDER BY id COLLATE "C";
\o export/rows/home_program_mapping.jsonl
SELECT row_to_json(t) FROM (SELECT basis, created_at::text AS created_at, evidence_url, id, name, policy_id, status FROM home_program_mapping) t ORDER BY id COLLATE "C";
\o export/rows/home_batch.jsonl
SELECT row_to_json(t) FROM (SELECT finished_at::text AS finished_at, id, source_id, started_at::text AS started_at, status FROM home_batch WHERE started_at > :'since'::timestamptz OR finished_at > :'since'::timestamptz OR finished_at IS NULL) t ORDER BY id COLLATE "C";
\o export/rows/home_audit.jsonl
SELECT row_to_json(t) FROM (SELECT id, recorded_at::text AS recorded_at FROM home_audit WHERE action LIKE '%\_REVIEW' AND recorded_at > :'since'::timestamptz) t ORDER BY id COLLATE "C";
\o
COMMIT;
