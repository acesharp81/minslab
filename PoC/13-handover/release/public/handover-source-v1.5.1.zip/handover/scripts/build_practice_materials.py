"""Publish verified practical reports; keep original reference and private workspace out."""
import json,hashlib,shutil
from pathlib import Path
from docx import Document
from app.practice_demo import PROFILES,resources
from app.flow_demo import WORKS
ROOT=Path(__file__).resolve().parents[1];out=ROOT/'release/public';run=ROOT/'test-results/practice/llm'
expected={'version':'practice-1','documents':15,'draft_tasks':5,'final_tasks':4,'reference_date':'2026-11-09','sample_sha256':hashlib.sha256((out/'practice-samples.zip').read_bytes()).hexdigest(),'works':[w|{'profile':PROFILES[i],'resources':resources(i)} for i,w in enumerate(WORKS)],'expected_progress':[65,40,100,75],'budgets_unique':5,'contacts_unique':11,'budget_totals':{'편성액':358000000,'집행액':212000000,'지급예정액':33000000,'가용잔액':113000000},'manual_match':{'source':'예약포털 접근성 보완','target':'문화시설 통합예약 개선','owner':'디지털지원팀','evidence':'09_업무동일성_담당확인.txt'},'scope':'합성 업무 자료. 추가 금액·인물·증빙은 시연용 창작. 기존 GPT 평가는 이전 7개 업무 자료에 한정.'}
(out/'practice-expected.json').write_text(json.dumps(expected,ensure_ascii=False,indent=2)+'\n')
md='''# 업무바통 사용·시연 안내서 v1.5.1

## 1. 바로 보기와 직접 체험

완성 보고서: https://www.minslab.kr/handover/downloads/practice-report.html

사용법·다운로드: https://www.minslab.kr/handover/guide

앱: https://www.minslab.kr/handover/ — 홈페이지 PoC → 13. 업무바통으로도 열 수 있습니다. 앱의 접속 코드는 운영자에게 별도로 받습니다. 자료실과 완성 예시는 로그인 없이 열립니다.

‘4개 업무 흐름 체험’을 누르면 15개 합성 원본 자료를 등록하고 Solar Pro 4 분석을 시작합니다. 수동 체험은 ‘새 인수인계’ → ‘여러 파일 선택’ → practice-samples.zip → ‘초안 생성’ → ‘AI 문서 해석’ → 합성 자료 외부 전송 동의 순서입니다. 로컬 규칙 모드는 명시적 라벨 분석이며 일반 문장에 대한 LLM 해석과 구분됩니다.

## 2. 파일 구성과 기대 결과

| 원본 자료 | 개수 | 역할 |
|---|---|---|
| 01~04 단계별 보고 | 11 | 계획·착수·중간·완료의 상태·일정·달성률 |
| 06_업무실무기준정보.xlsx | 1 | 개요·목표·범위·추진 계획·절차·완료 기준 |
| 07_공통예산연락망.xlsx | 1 | 예산 코드·집행·지급 예정·가용 잔액·담당·협의처 |
| 08_실행증빙대장.xlsx | 1 | 접수·검토·점검·결함을 확인하는 시연용 대장 |
| 09_업무동일성_담당확인.txt | 1 | 마지막 두 업무 후보의 동일 범위·진행률 기준·담당 확인 |

전체 DOCX 4개·XLSX 6개·텍스트 PDF 3개·TXT 2개입니다. 문서역할이 ‘업무기준정보’인 자료는 최신 진행보고를 덮어쓰지 않습니다. 항목명이 명시된 기준정보는 원문 그대로 읽는 구조화 추출을 사용하고, 진행보고는 Solar가 해석합니다. 증빙대장은 독립 업무가 되지 않으며 검색·원본 열람용으로 보존됩니다.

| 업무 | 보고 흐름 | 최신 달성률 | 2026-11-09 기준 현안 |
|---|---|---|---|
| 생활문화 공모사업 추진 | 계획 → 착수 → 중간 | 65% | 11/12 기한, A07·A14 보완 필요 |
| 보조금 정산 승인 | 계획 → 착수 → 중간 | 40% | 11/06 기한 경과, G05·G06 영수증 누락 |
| 문화시설 안전점검 | 계획 → 착수 → 완료 | 100% | 11/05 완료, 완료 증빙 인수·차기 점검 준비 |
| 문화시설 통합예약 개선 | 계획 → 담당자 확인 → 중간 | 75% | 11/24 기한, D01·D02 키보드 오류 미해결 |

## 3. 같은 업무로 매칭하기

초안은 5개 후보입니다. ‘예약포털 접근성 보완’의 ‘같은 업무로 매칭’ → ‘문화시설 통합예약 개선’을 선택합니다. 09_업무동일성_담당확인.txt를 열어 두 보고가 같은 사업 전체 범위이고 20%·75%가 동일 기준의 서로 다른 시점인지 확인합니다.

담당은 ‘디지털지원팀’, 사유는 ‘09_업무동일성_담당확인.txt에서 동일 사업 범위·보고 진행률 기준·담당을 대조’로 입력하고 확인 체크 후 저장합니다. 결과는 4개 업무입니다. 실제 자료에서는 확인한 담당자의 응답을 사유에 기록해야 합니다. 관리번호가 같다는 이유만으로 자동 연결하지 않습니다.

## 4. 항목별 검토·수정과 확정

각 항목 옆 연필을 누르면 현재 값·수정값·변경 사유와 관련 근거를 함께 볼 수 있습니다. ‘업무 개요·계획·실무 절차·예산·연락망 확인’ 영역을 펼치면 상세실무편의 추가 항목도 각각 수정할 수 있습니다. 선택한 항목만 새 판본에 저장하며 변경 이력을 남깁니다.

필수 미기재가 없는지, 원문 기록과 전임자 입력이 구분되는지 확인하고 ‘검토 완료 · 확정하기’ → 확인 체크 → ‘이 판본 확정’을 누릅니다. 원문 추출 PARTIAL은 입력란 미정과 다른 개념입니다. DOCX의 본문·표 밖 범위 안내 등이 남을 수 있으며 원본에서 확인합니다. 보고서의 자료 검토 참고에 별도로 표시됩니다.

## 5. 완성 보고서를 읽는 순서

첫 화면의 간트에서 계획 기간·원문 달성률·지연 일수·실제 완료일을 확인합니다. 색 막대는 경과 시간으로 계산한 값이 아닙니다. 확정일이 달라지면 D-n과 지연 일수도 달라집니다. 배포 예시는 2026-11-09 기준입니다.

우선순위 페이지에서 기한 경과·임박 업무와 당장 할 일을 확인합니다. 각 업무의 A면은 개요·목표·인계 범위·보고 흐름·현재 진척·개별 실적·현안 경과, B면은 추진 계획·담당과 일정별 추후 계획·실무 순서·완료 기준·인계 산출물·결재·자료 위치를 담습니다.

공통 예산은 같은 예산코드를 한 번만 합산합니다. 5개 예산의 편성 합계 358,000,000원, 집행 212,000,000원, 지급 예정 33,000,000원, 가용 잔액 113,000,000원입니다. 공통 B-COM이 4개 업무에 등장해도 4번 합산하지 않습니다. 금액·기준일이 충돌하면 합계를 확정하지 않습니다. 연락망은 관계자ID 기준 11명이며 공통 회계·자료 지원 담당의 중복을 제거합니다.

과거 현안은 해소 기록이 있는 경우에만 해소로 설명합니다. 앞으로 만들 승인문·검수 결과는 제공된 증빙으로 표시하지 않습니다. 모든 인명·연락·금액·기록은 가상이며 실제 공문·영수증·현장 사진은 포함하지 않습니다.

## 보고서 화면의 목차와 챗봇

보고서 탭은 화면 높이에 맞춰 열리며 본문 안에서 스크롤합니다. 왼쪽 목차는 상위 주제만 먼저 보입니다. 화살표 또는 상위 제목을 누르면 세부 항목이 펼쳐지며 다시 누르면 접힙니다. 제목 클릭 시 본문도 해당 위치로 이동합니다. 작은 화면에서는 상위 제목을 펼쳐도 목차를 유지하고 하위 항목 선택 시 본문을 보여줍니다. 작은 화면에서는 위쪽 ‘목차’, ‘챗봇’ 버튼으로 패널을 열고 닫습니다.

상단의 역할 선택과 Solar 추정 잔액은 고정됩니다. 잔액을 누르면 $100 기준 사용량, 집계 시작 시점과 실제 Upstage 결제 콘솔 링크를 확인할 수 있습니다. 앱 집계 이전·외부 사용, 할인·세금 및 사용량 미확인 호출은 반영하지 않는 추정치입니다.

오른쪽 보고서 챗봇에서 ‘보조금 정산 남은 업무는?’처럼 질문합니다. Solar Pro 4 AI 질의는 질문·이전 질문·확정 보고서·관련 자료의 전송 동의 후 사용할 수 있습니다. ‘키워드 검색’은 외부 전송 없이 조회합니다. AI 답변은 실제 생성되는 대로 커서와 함께 글자 단위로 표시됩니다. 생성 중 문장은 미완성 상태이며, 완료 후 근거 검증을 통과하면 출처 버튼이 연결됩니다. 연결 오류나 근거 검증 실패 시 미완성 문장은 제거하고 오류를 표시합니다. AI는 결론·이유·바로 할 일을 문장으로 설명하며 문단별 ‘근거 확인’을 펼쳐 원문과 확정값을 볼 수 있습니다. 우선순위는 보고서에 근거한 AI 판단이며 이후 진행 상황은 별도 확인합니다. ‘그럼 담당은?’ 같은 후속 질문은 앞선 질문의 업무를 참고합니다.

답변은 확정 보고서에 기록된 값을 표시하고 원문 근거 버튼을 제공합니다. 참고자료는 별도 펼침 영역에 표시하며 과거 원문이 수정·확정한 값을 덮어쓰지 않습니다. 자료가 없으면 답을 추정하지 않습니다. 질문·근거 열람 중에도 읽던 보고서 위치를 유지합니다. 새 확정 판본이나 다른 인수인계함에서는 대화 범위를 새로 시작합니다.

## 6. 다운로드·후임자 확인

practice-report.html/pdf/docx/md는 같은 Solar 분석·담당자 매칭·확정 판본에서 생성한 예시입니다. HTML·PDF는 간트·추이·실적·예산 차트를, DOCX는 간트 이미지와 편집 가능한 표를, MD는 원문 인용까지 포함한 텍스트를 제공합니다.

앱의 ‘인쇄 / PDF 저장’ 또는 ‘보고서 새 창’에서 출력할 수 있습니다. 오른쪽 위 역할을 ‘후임자’로 바꾸면 같은 보고서를 읽고 ‘인수 확인’을 남깁니다. 수정 초안은 기존 확정본을 자동 교체하지 않습니다. 수정 후 다시 확정해야 후임자의 최종본이 바뀝니다. DOCX 외부 편집도 앱에는 반영되지 않습니다.

## 7. 직접 실행·검증 범위

Python 3.12: 소스 ZIP 해제 → python3 -m venv .venv → .venv/bin/pip install -r requirements.lock → .env.example을 .env로 복사 → Upstage 키·접속 코드 설정 → bash scripts/run.sh. 기본 주소는 http://127.0.0.1:18130/ 입니다.

Docker: docker build -t poc13-handover:1.5.1 . → docker compose up -d. 전용 볼륨에 자료를 보존합니다. 소스 ZIP에는 운영 키·DB가 없습니다. 검사: bash scripts/verify.sh.

practice-expected.json은 원본 정답, practice-validation.json은 이번 실무 샘플의 실제 Solar 대조·출력·기능 검증 기록입니다. ‘100점’ 점검표는 이번 합성 시나리오의 정해진 항목 충족 여부이며 일반 문서 정확도나 외부 인증을 뜻하지 않습니다. 기존 GPT-5.4-mini 1회 평가 결과는 이전 7개 업무 샘플에 한정하여 유지하며 새 GPT 호출은 하지 않았습니다.

텍스트 PDF·DOCX·XLSX·TXT·HWP/HWPX 본문을 지원합니다. 스캔 OCR·복잡한 한글 서식 재현·기관 SSO·개인별 권한·전자서명은 범위 밖입니다. 역할 선택은 시연 기능입니다. 사용 라이선스는 docs/THIRD_PARTY_NOTICES.md를 참고하세요. 시연 영상과 참가 접수는 별도 진행합니다.
'''
(out/'handover-guide.md').write_text(md);(ROOT/'docs/submission/USER_GUIDE.md').write_text(md)
doc=Document()
for line in md.splitlines():
 if line.startswith('# '):doc.add_heading(line[2:],0)
 elif line.startswith('## '):doc.add_heading(line[3:],1)
 elif line:doc.add_paragraph(line)
doc.save(out/'handover-guide.docx')
if (run/'result.json').exists():
 for fmt in ['html','pdf','docx','md']:
  shutil.copyfile(run/f'practice-report.{fmt}',out/f'practice-report.{fmt}')
  shutil.copyfile(run/f'practice-report.{fmt}',ROOT/'docs'/f'최종_인수인계_상세실무편_20261109.{fmt}')
print('Practical guide, expected data and verified reports prepared')
