"""List only deliberate public deliverables; no workspace file enumeration."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'release/public'
CATALOG=[
 ('practice-samples.zip','4개 업무 · 상세실무 원본 15개','단계별 보고·실무 기준·예산·연락망·증빙·동일업무 확인'),
 ('practice-report.html','완성된 상세실무편 HTML','간트·보고 흐름·실행서·공통 예산·관계자'),
 ('practice-report.pdf','완성된 상세실무편 PDF','원본에서 실제 생성한 최종 보고서'),
 ('practice-report.docx','완성된 상세실무편 DOCX','동일 확정본의 편집 가능한 사본'),
 ('practice-report.md','완성된 상세실무편 Markdown','원문 인용과 수정 이력을 포함한 텍스트'),
 ('handover-guide.pdf','사용·구동 안내서 PDF','15개 원본으로 처음부터 따라 하기'),
 ('handover-guide.docx','사용 안내서 DOCX','편집 가능한 사용 설명서'),
 ('handover-guide.md','사용 안내서 Markdown','텍스트 사용 설명서'),
 ('practice-expected.json','실무 샘플 정답표','업무별 실무 내용·금액·관계자·예상 결과'),
 ('practice-validation.json','실무 보고서 최종 검증','이번 Solar 원문 대조·기능·출력 검증과 충족 기준'),
 ('practice-review.md','최종 보고서 검토 결과','개선 내용·점검 결과·검증 범위'),
 ('quality-report.md','기존 모델 품질 비교 결과','이전 7개 업무 샘플의 GPT 1회 검증 보존'),
 ('quality-results.json','기존 품질 측정 JSON','이전 7개 업무에 한정된 측정 결과'),
 ('handover-source-v1.2.0.zip','프로그램 소스·실행 패키지','설치·테스트·라이선스 고지 포함'),
 ('handover-demo-kit-v1.2.0.zip','체험 자료 한 번에 받기','샘플·안내서·최종 보고서·검증 기록'),
 ('flow-samples.zip','이전 단계별 보고 샘플 11개','호환 체험 자료'),
 ('flow-report.html','이전 간트 중심 보고서 HTML','이전 확정본 보존'),
 ('flow-report.pdf','이전 간트 중심 보고서 PDF','이전 확정본 보존'),
 ('flow-validation.json','이전 4개 업무 검증 결과','이전 11개 원본 분석 기록')]
files=[]
for name,title,description in CATALOG:
 p=out/name
 if p.is_file():files.append({'file':name,'title':title,'description':description,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'version':'1.2.0','synthetic_only':True,'files':files},ensure_ascii=False,indent=2)+'\n')
print('Public deliverables:',len(files))
