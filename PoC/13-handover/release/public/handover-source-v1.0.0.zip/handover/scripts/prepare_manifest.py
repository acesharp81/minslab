"""List only deliberate public deliverables; no workspace file enumeration."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'release/public'
CATALOG=[('handover-samples.zip','업무용 샘플 7개','DOCX·XLSX·PDF·TXT를 직접 올려 체험'),('handover-guide.pdf','사용·구동 안내서 PDF','처음부터 따라 하는 5쪽 안내'),('handover-guide.docx','사용 안내서 DOCX','편집 가능한 사용 설명서'),('handover-guide.md','사용 안내서 Markdown','텍스트 사용 설명서'),('expected.json','샘플 정답표','예상 업무·현안·기한과 검증 기준'),('sample-report.pdf','완성된 샘플 보고서 PDF','실제 Solar 분석 후 전임자 수정·확정'),('sample-report.docx','완성된 샘플 보고서 DOCX','동일 확정본의 편집용 사본'),('sample-report.html','완성된 샘플 보고서 HTML','오프라인 열람·인쇄'),('sample-report.md','완성된 샘플 보고서 MD','동일 확정본의 텍스트'),('quality-report.md','모델 품질 비교 결과','GPT 1회 검증·Solar 프롬프트 개선과 한계'),('quality-results.json','품질 측정 JSON','샘플 정답표·원문 일치 측정'),('handover-source-v1.0.0.zip','프로그램 소스·실행 패키지','설치·테스트·라이선스 고지 포함'),('handover-demo-kit-v1.0.0.zip','체험 자료 한 번에 받기','샘플·안내서·완성 보고서·품질 결과')]
files=[]
for name,title,description in CATALOG:
 p=out/name
 if p.is_file():files.append({'file':name,'title':title,'description':description,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'version':'1.0.0','synthetic_only':True,'files':files},ensure_ascii=False,indent=2)+'\n')
print('Public deliverables:',len(files))
