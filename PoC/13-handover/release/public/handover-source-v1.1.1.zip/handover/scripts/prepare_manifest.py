"""List only deliberate public deliverables; no workspace file enumeration."""
import hashlib,json
from pathlib import Path
root=Path(__file__).resolve().parents[1];out=root/'release/public'
CATALOG=[('flow-samples.zip','4개 업무 · 단계별 보고서 11개','DOCX·XLSX·PDF·TXT를 직접 올려 체험'),('handover-guide.pdf','사용·구동 안내서 PDF','담당자 매칭·간트 보고서 체험 안내'),('handover-guide.docx','사용 안내서 DOCX','편집 가능한 사용 설명서'),('handover-guide.md','사용 안내서 Markdown','텍스트 사용 설명서'),('flow-expected.json','샘플 정답표','예상 업무·현안·기한과 검증 기준'),('flow-report.pdf','완성된 샘플 보고서 PDF','Solar 분석·담당자 매칭·간트 차트 포함'),('flow-report.docx','완성된 샘플 보고서 DOCX','동일 확정본의 편집용 사본'),('flow-report.html','완성된 샘플 보고서 HTML','오프라인 열람·인쇄'),('flow-report.md','완성된 샘플 보고서 MD','동일 확정본의 텍스트'),('quality-report.md','모델 품질 비교 결과','이전 7개 업무 샘플의 GPT 1회 검증 보존'),('quality-results.json','품질 측정 JSON','이전 7개 업무 샘플의 품질 측정'),('handover-source-v1.1.1.zip','프로그램 소스·실행 패키지','설치·테스트·라이선스 고지 포함'),('handover-demo-kit-v1.1.1.zip','체험 자료 한 번에 받기','샘플·안내서·완성 보고서·품질 결과')]
CATALOG.insert(10,('flow-validation.json','새 4개 업무 흐름 검증 결과','Solar 분석·원문 대조·브라우저 시연 결과'))
files=[]
for name,title,description in CATALOG:
 p=out/name
 if p.is_file():files.append({'file':name,'title':title,'description':description,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
(out/'manifest.json').write_text(json.dumps({'version':'1.1.1','synthetic_only':True,'files':files},ensure_ascii=False,indent=2)+'\n')
print('Public deliverables:',len(files))
