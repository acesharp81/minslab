업무바통 직접 시연 자료
1. handover-guide.pdf를 읽습니다.
2. flow-samples.zip을 앱에 등록합니다.
3. flow-report.*은 실제 모델 분석·전임자 수정·확정 결과 예시입니다.
4. flow-expected.json과 quality-report.md에서 검증 기준과 한계를 확인합니다.
영상 제작 및 참가 접수는 이번 묶음에 포함하지 않습니다.
