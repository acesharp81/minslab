const $ = (s, parent = document) => parent.querySelector(s);
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const state = {cases:[], config:{}, current:null, details:null, revision:null, tab:'sources', role:localStorage.getItem('handover-role') || 'predecessor', timer:null};
const modelLabel = model => ({'solar-pro4':'Solar Pro 4','solar-mini4':'Solar Mini 4'}[model] || model);
const labels = {title:'업무명',status:'현재 상태',due_date:'기한',owner:'담당',next_action:'다음 행동',notes:'참고 사항',completed_work:'완료한 일·산출물',remaining_work:'남은 업무',issues:'현안·장애 사항',collaborators:'협의·협업 부서',contacts:'연락처'};
Object.assign(labels,{overview:'업무 개요',objectives:'목표',scope:'업무 범위',implementation_plan:'추진 계획',performance:'성과 지표',future_plan:'추후 계획',operating_steps:'실무 처리 순서',completion_criteria:'완료 기준',deliverables:'인계 산출물',issue_history:'현안 경과',approval_route:'보고·결재 체계',document_locations:'자료 위치·접근 방법',budget:'예산 현황'});
const statuses = {PENDING:['대기','gray'],SUCCESS:['추출 완료','green'],PARTIAL:['부분 추출','orange'],FAILED:['추출 실패','red'],UNSUPPORTED:['미지원','gray']};
const date = value => value ? new Date(value).toLocaleString('ko-KR',{month:'2-digit',day:'2-digit',hour:'2-digit',minute:'2-digit'}) : '—';
const apiBase = new URL('api/', location.href);
const apiUrl = path => new URL(path.replace(/^\//,''), apiBase).href;
async function api(path, options={}) {
  const headers = {'X-Role':state.role, ...options.headers};
  if(options.body && !(options.body instanceof FormData)) {headers['Content-Type']='application/json';options.body=JSON.stringify(options.body);}
  const response = await fetch(apiUrl(path),{...options,headers});
  if(path!=='budget'&&options.method&&options.method!=='GET')setTimeout(refreshBudget,100);
  const value = await response.json().catch(()=>({detail:'서버 응답을 읽지 못했습니다.'}));
  if(!response.ok){if(response.status===401) loginDialog();throw new Error(typeof value.detail==='string'?value.detail:'입력값을 확인해 주세요.');}
  return value;
}
let toastTimer;
function toast(message){$('#toast').textContent=message;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),5500);}
function badge(text, tone=''){return `<span class="badge ${tone}">${esc(text)}</span>`;}
function button(action,text,style='',data=''){return `<button class="button ${style}" data-action="${action}" ${data}>${text}</button>`;}
function closeDialog(){state.fieldEdit=null;$('#dialog').close();$('#dialog').classList.remove('field-edit-dialog');}
function modal(title,subtitle,body,actions){state.fieldEdit=null;$('#dialog').classList.remove('field-edit-dialog');$('#dialogBody').innerHTML=`<div class="modal-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle)}</p></div><button class="icon-button" data-action="close" aria-label="닫기">×</button></div><div class="modal-content">${body}</div><div class="modal-actions">${actions}</div>`;if(!$('#dialog').open)$('#dialog').showModal();}
async function init(){
  $('#roleSelect').value=state.role;$('#avatar').textContent=state.role==='predecessor'?'전':'후';
  try{state.config=await api('config');refreshBudget();state.cases=await api('cases');renderSidebar();$('#modeFooter').textContent=state.config.llm_available?`LLM 연결 · ${modelLabel(state.config.model)}`:'로컬 규칙 추출 · LLM 미연결';const saved=location.hash.slice(1);if(saved&&state.cases.some(c=>c.id===saved))await openCase(saved);else renderHome();}catch(e){toast(e.message);}
}
function renderSidebar(){
  $('#caseCount').textContent=state.cases.length;
  $('#caseList').innerHTML=state.cases.map(c=>`<button class="case-link ${c.id===state.current?'selected':''}" data-action="open-case" data-id="${c.id}">${esc(c.title)}</button>`).join('');
}
function renderHome(){
  disposeReportReader();
  clearTimeout(state.timer);state.current=null;state.details=null;state.revision=null;location.hash='';renderSidebar();$('#breadcrumb').textContent='인수인계함';
  $('#main').innerHTML=`<div class="page-heading"><div><div class="eyebrow">Your next chapter</div><h1>업무를 잇는 가장 좋은 시작.</h1><p class="subtitle">흩어진 자료를 모아, 다음 사람이 바로 시작할 수 있는 인수인계로.</p></div>${state.role==='predecessor'?button('new-case','＋ 새 인수인계','primary'):''}</div>
  <section class="hero"><div><div class="eyebrow">Context stays. Work continues.</div><h2>업무의 흐름과 일정,<br>한눈에 인수인계.</h2><p>원문에서 업무를 찾고, 전임자가 검토하고, 후임자에게 전달합니다.<br>${state.config.llm_available?'합성 샘플을 '+esc(modelLabel(state.config.model))+'에 전송하여 실제 AI 분석을 체험합니다.':'합성 샘플 자료로 전체 과정을 직접 경험해 보세요.'}</p><div class="buttons">${state.role==='predecessor'?button('start-demo','4개 업무 흐름 체험 <span>↗</span>','primary'):button('switch-predecessor','전임자로 시작하기','primary')}<a class="button ghost" href="samples/practice.zip">업무용 샘플 ZIP 받기 ↓</a><a class="button ghost" href="guide" target="_blank" rel="noopener">사용법·시연 자료 ↗</a></div></div><div class="hero-art" aria-hidden="true"><div class="art-sheet"><i></i><i></i><i></i><i></i><div class="art-seal">검토 완료 ✓</div></div><div class="art-baton"></div><div class="art-tag">✧ 업무의 다음 페이지</div></div></section>
  <div class="section-heading"><h2>나의 인수인계함 <span>${state.cases.length}</span></h2><span>최근 생성순</span></div>
  ${state.cases.length?`<div class="case-grid">${state.cases.map(c=>`<button class="case-card" data-action="open-case" data-id="${c.id}">${badge(c.confirmed?'확정본 있음':c.current?'초안 검토 중':'자료 등록 대기',c.confirmed?'green':'gray')}<h3>${esc(c.title)}</h3>${c.mode?badge(c.mode==='llm'?'AI 분석':'로컬 규칙',c.mode==='llm'?'green':'gray'):''}<p>${esc(c.predecessor)} <span>→</span> ${esc(c.successor)}</p><div class="card-bottom"><span>${date(c.created)} 생성</span><span>열어보기 ↗</span></div></button>`).join('')}</div>`:`<div class="empty"><h3>첫 번째 인수인계함을 만들어 보세요.</h3><p>업무자료 ZIP 또는 문서 파일을 등록하면, 원문과 연결된 업무 초안을 만들 수 있습니다.</p>${button('new-case','인수인계함 만들기','small')}</div>`}
  <div class="notice"><span>ⓘ</span><p><strong>직접 확인하는 인수인계</strong> · 추출 결과는 초안입니다. 원문과 다른 기한·담당은 전임자가 수정하고 확정합니다. 이 서비스의 역할 선택은 시연용이며 기관 인증·전자결재가 아닙니다.</p></div>`;
}
function caseDialog(){modal('새 인수인계함','한 업무 묶음의 자료와 검토 이력을 한곳에 보관합니다.',`<label class="form-field">인수인계 이름<input id="caseTitle" maxlength="150" placeholder="예: 문화기획팀 업무 인수인계" autofocus></label><div class="form-grid"><label class="form-field">전임자 표시명<input id="predecessor" maxlength="80" value="전임자"></label><label class="form-field">후임자 표시명<input id="successor" maxlength="80" value="후임자"></label></div>`,button('close','취소')+button('create-case','만들기','primary'));}
async function createCase(title, predecessor='전임자', successor='후임자'){const c=await api('cases',{method:'POST',body:{title,predecessor,successor}});state.cases=await api('cases');return c;}
async function openCase(id, tab){
  clearTimeout(state.timer);state.current=id;location.hash=id;if(tab)state.tab=tab;else state.tab=state.cases.find(c=>c.id===id)?.confirmed?'report':state.role==='successor'?'report':'sources';
  await refresh();
}
async function refresh(){
  const id=state.current;if(!id)return;
  const details=await api(`cases/${id}`);if(state.current!==id)return;state.details=details;
  const pointer=state.role==='successor'||['confirmed','report','briefing','questions'].includes(state.tab)?'confirmed':'current';
  state.revision=await api(`cases/${id}/revisions/${pointer}`);
  if(state.tab==='briefing'&&details.confirmed)state.briefing=await api(`cases/${id}/briefing`);else state.briefing=null;
  const qaKey=id+':'+(details.confirmed||'');if(state.qaKey!==qaKey){state.qaKey=qaKey;state.answers=[];state.qaConsent=false;}
  if(state.current!==id)return;
  renderSidebar();renderCase();
  if(details.jobs.some(j=>['RUNNING','QUEUED'].includes(j.status)))state.timer=setTimeout(()=>refresh().catch(e=>toast(e.message)),1500);
}
function renderCase(){
  disposeReportReader();
  const d=state.details, rev=state.revision, items=rev?.payload.items||[];$('#breadcrumb').textContent=d.title;
  const docs=d.documents;const warnings=rev?.warnings.length||0;const active=d.jobs.find(j=>['RUNNING','QUEUED'].includes(j.status));
  const coverage=rev?.payload.coverage||[];const scanned=coverage.reduce((a,c)=>a+c.scanned_blocks,0),reviewed=coverage.reduce((a,c)=>a+c.reviewed_blocks,0);
  $('#main').innerHTML=`<div class="page-heading"><div><div class="eyebrow">Handover workspace</div><h1>${esc(d.title)}</h1><p class="subtitle">${esc(d.predecessor)} <span>→</span> ${esc(d.successor)} &nbsp;·&nbsp; ${date(d.created)} 생성</p></div><div class="buttons">${button('home','← 목록','small ghost')}${d.confirmed?button('open-report','인수인계 보고서 보기','primary'):''}${state.role==='predecessor'?button('generate',d.current?'새 초안 생성':'초안 생성','primary',active?'disabled':''):badge('후임자 열람','green')}</div></div>
  <div class="steps"><div class="step on"><b>1</b>자료 등록</div><div class="step-line"></div><div class="step ${d.current?'on':''}"><b>2</b>초안 검토</div><div class="step-line"></div><div class="step ${d.confirmed?'on':''}"><b>3</b>확정·전달</div><div class="step-line"></div><div class="step ${d.accepted?'on':''}"><b>4</b>후임자 확인</div></div>
  <div class="stats"><div class="stat"><div class="label">등록 자료</div><strong>${docs.length}<small> 개</small></strong><small>파일 판본 보존</small></div><div class="stat"><div class="label">정리된 업무</div><strong>${items.length}<small> 건</small></strong><small>${rev?rev.payload.mode==='llm'?'AI 문서별 추출':'로컬 규칙 추출':'초안 생성 후 표시'}</small></div><div class="stat"><div class="label">검토 범위</div><strong>${reviewed}<small> / ${scanned} 블록</small></strong><small>읽은 본문 중 추출 검토 범위</small></div><div class="stat"><div class="label">확인 필요</div><strong>${warnings}<small> 건</small></strong><small>미확인 값·부분 추출 포함</small></div></div>
  ${modelUsage(rev)}
  ${jobView(d.jobs[0])}
  <nav class="tabs" aria-label="인수인계 단계">${(state.role==='predecessor'?[['sources','업무자료',docs.length],['review','초안 검토',d.current?'•':''],['report','인수인계 보고서',d.confirmed?'✓':''],['briefing','일정·연락망',''],['questions','보고서에 질문',''],['confirmed','확정 업무보드',d.confirmed?'✓':''],['history','변경 이력',d.history.length]]:[['report','인수인계 보고서',''],['briefing','일정·연락망',''],['questions','보고서에 질문',''],['confirmed','확정 업무보드',''],['sources','근거 자료',docs.length],['history','확정 이력','']]).map(([key,label,count])=>`<button class="tab ${state.tab===key?'active':''}" data-action="tab" data-tab="${key}">${label} <span>${count}</span></button>`).join('')}</nav>
  ${state.tab==='sources'?sourcesView():state.tab==='history'?historyView():state.tab==='report'?reportView():state.tab==='briefing'?briefingView():state.tab==='questions'?questionsView():reviewView(state.tab==='confirmed')}`;
  const reportFrame=$('#reportFrame');if(reportFrame)mountReportReader(reportFrame);
  const zone=$('#dropZone');if(zone){zone.addEventListener('dragover',e=>{e.preventDefault();zone.classList.add('drag');});zone.addEventListener('dragleave',()=>zone.classList.remove('drag'));zone.addEventListener('drop',e=>{e.preventDefault();zone.classList.remove('drag');if(e.dataTransfer.files.length)uploadFiles(e.dataTransfer.files).catch(e=>toast(e.message));else toast('폴더는 폴더 선택 버튼으로 등록해 주세요.');});}
}
function modelUsage(revision){
  if(!revision || revision.payload.mode!=='llm')return '';
  const rows=revision.payload.coverage;
  const calls=rows.reduce((n,r)=>n+(r.calls?.length||0),0);
  const tokens=rows.reduce((n,r)=>n+(r.usage?.total_tokens||0),0);
  return `<details class="model-usage"><summary>모델 사용 기록</summary><p>${esc(modelLabel(revision.payload.model))} · ${calls}회 요청 · ${tokens.toLocaleString()} 토큰</p><p class="muted">이 판본을 생성할 때의 실제 호출 기록입니다. 모델의 검토가 의미 정확성을 보증하지는 않습니다.</p><a class="text-link" href="${apiUrl('demo.zip?expanded=true')}">비정형 문서 포함 확장 샘플 12개 받기 ↓</a></details>`;
}
function jobView(job){
  if(!job)return '';
  if(['QUEUED','RUNNING'].includes(job.status))return `<div class="job"><div class="job-header"><span><i class="spinner"></i>${({QUEUE:'자료 처리 준비',PARSE:'파일별 원문 추출',DISCOVER:'문서별 업무 후보 추출',MERGE:'업무 통합·근거 연결'})[job.stage]||'처리 중'}</span><small>${job.progress}% · 새로 고쳐도 계속됩니다</small></div><progress class="progress" value="${job.progress}" max="100" aria-label="문서 처리 진행률"></progress></div>`;
  if(['FAILED','INTERRUPTED'].includes(job.status))return `<div class="notice"><span>!</span><div><strong>처리를 완료하지 못했습니다.</strong><p>${esc(job.error)}</p></div>${state.role==='predecessor'?button('retry','다시 시도','small',`data-id="${job.id}"`):''}</div>`;
  return '';
}
function sourcesView(){
  const docs=state.details.documents,coverage=state.revision?.payload.coverage||[];
  return `${state.role==='predecessor'?`<div class="upload-zone" id="dropZone"><span class="upload-icon">↥</span><div><h3>업무자료를 여기에 놓아주세요.</h3><p>ZIP · HWP/HWPX · PDF · DOCX · XLSX · TXT &nbsp;|&nbsp; 파일당 20MB, ZIP 80MB</p></div><div class="buttons">${button('upload','여러 파일 선택','small primary')}${button('upload-folder','폴더 선택','small')}${button('sample','샘플 자료 추가','small')}</div></div>`:''}
  <div class="section-heading"><h2>등록한 자료</h2><span>원문은 변경하지 않고 판본으로 보존합니다.</span></div>
  ${docs.length?`<div class="table-wrap"><table><thead><tr><th>자료명</th><th>추출 상태</th><th>검토 범위</th><th>원문</th></tr></thead><tbody>${docs.map(doc=>{const cov=coverage.find(c=>c.document_id===doc.id);return `<tr><td><div class="file-name"><span class="file-icon">${esc(doc.format.slice(1).toUpperCase())}</span>${esc(doc.path)}</div>${doc.warnings.length?`<div class="file-warning">${esc(doc.warnings.join(' '))}</div>`:''}<small class="muted">판본 ${doc.id.slice(0,8)}</small></td><td>${badge(...statuses[doc.status])}<div class="muted">${doc.block_count} 블록</div></td><td><span class="muted">${cov?`${cov.reviewed_blocks} / ${cov.scanned_blocks} 블록 검토`:'미검토'}</span>${cov?.unreviewed_block_ids.length?`<div class="file-warning">${cov.unreviewed_block_ids.length} 블록 추가 확인</div>`:''}</td><td><button class="text-link" data-action="document" data-id="${doc.id}">본문 보기 ↗</button><br><a class="text-link" href="${apiUrl(`cases/${state.current}/documents/${doc.id}/raw`)}">원본 받기 ↓</a></td></tr>`;}).join('')}</tbody></table></div>`:`<div class="empty"><h3>아직 등록한 자료가 없습니다.</h3><p>여러 파일을 담은 ZIP으로 시작하거나 샘플을 추가해 보세요.</p></div>`}
  <div class="notice"><span>ⓘ</span><p>텍스트 기반 문서와 단순 표를 우선 지원합니다. 이미지·스캔 PDF의 OCR, 복잡한 도형·수식은 지원하지 않습니다. 부분 추출 사유와 미검토 범위를 확인하세요.</p></div>`;
}
function fieldView(item,key,field,editable=false){
  const refs=field.evidence.length?field.evidence:field.previous?.evidence||[];
  const human=field.provenance==='HUMAN_ENTERED';const conflict=field.review_status==='CONFLICT';
  return `<div class="field ${!['title','status','owner','due_date'].includes(key)?'wide':''} ${conflict?'conflict':''} ${human?'human':''}"><div class="field-heading"><label>${labels[key]} ${human?badge('전임자 확인','green'):conflict?badge('기한 대조','orange'):field.review_status==='NEEDS_CONFIRMATION'&&field.value?badge('확인 필요','orange'):''}</label>${editable?pencil(item,key):''}</div><div class="value">${esc(field.value)||'<span class="muted">미확인</span>'}</div>${refs.length||field.previous?`<button class="source-button" data-action="evidence" data-id="${item.id}" data-field="${key}">${human?'수정 이력·과거 근거':'↗ 원문 근거 '+refs.length+'개'}</button>`:''}</div>`;
}
function reviewView(confirmed){
  const rev=state.revision;if(!rev)return `<div class="empty"><h3>${confirmed?'아직 전달된 확정본이 없습니다.':'검토할 초안을 만들어 주세요.'}</h3><p>${confirmed?'전임자가 초안을 검토·확정하면 이곳에서 업무를 확인할 수 있습니다.':'자료를 등록한 뒤 초안 생성을 누르면, 원문과 연결된 업무 카드가 만들어집니다.'}</p>${!confirmed&&state.role==='predecessor'?button('generate','초안 생성','primary'):''}</div>`;
  const editable=!confirmed&&state.role==='predecessor';
  return `${confirmed?`<div class="success-header"><div class="success-icon">✓</div><div><h3>전임자가 확인한 인수인계본입니다.</h3><p>${date(rev.confirmation?.created)} 확정 · 판본 ${rev.id.slice(0,8)}${state.details.accepted?' · 후임자 확인 완료':''}</p></div><div class="buttons"><a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.md`)}">MD ↓</a><a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.html`)}">HTML ↓</a><a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.docx`)}">DOCX ↓</a>${state.role==='successor'?button('accept',state.details.accepted?'확인 완료 ✓':'인수 확인','small primary'):''}</div></div>`:`<div class="section-heading"><div><h2>원문에서 찾은 업무, 함께 확인해 주세요.</h2><p class="subtitle">${rev.payload.mode==='llm'?'AI가 문서별로 추출한':'로컬 규칙으로 추출한'} 초안입니다. 필드의 원문 근거를 눌러 확인할 수 있습니다.</p></div>${editable?button('add-item','＋ 업무 추가','small'):''}</div>`}
  ${editable?readinessView(rev):''}
  ${rev.warnings.length?`<div class="notice"><span>!</span><p><strong>${rev.warnings.length}개 확인 필요 사항이 있습니다.</strong> 기한 불일치·담당 미확인·부분 추출 내용은 확정 후에도 표시됩니다. ${button('warnings','자세히 보기','small ghost')}</p></div>`:''}
  <div class="review-layout"><div><div class="work-list">${rev.payload.items.map((item,index)=>`<article class="work-card"><div class="work-top"><div><div class="work-number">WORK ${String(index+1).padStart(2,'0')}</div><div class="work-title"><h3>${esc(item.fields.title.value)}</h3>${editable?pencil(item,'title'):''}</div></div>${editable?button('match','같은 업무로 매칭','small',`data-id="${item.id}"`):badge('확정본 수록','green')}</div><div class="work-grid">${Object.keys(labels).filter(k=>['status','owner','due_date','completed_work','remaining_work','next_action','issues','notes','collaborators'].includes(k)).map(key=>fieldView(item,key,item.fields[key]||{value:'',evidence:[]},editable)).join('')}</div><details class="practice-fields"><summary>업무 개요·계획·실무 절차·예산·연락망 확인 / 항목별 수정</summary><div class="work-grid">${Object.keys(labels).filter(k=>!['title','status','owner','due_date','completed_work','remaining_work','next_action','issues','notes','collaborators'].includes(k)).map(key=>fieldView(item,key,item.fields[key]||{value:'',evidence:[]},editable)).join('')}</div></details><div class="work-bottom"><span>${item.source_documents.length}개 자료 연결${item.merge_note?' · 같은 업무인지 검토 필요':''}</span><button class="text-link" data-action="evidence" data-id="${item.id}" data-field="title">업무명 근거 ↗</button>${editable?button('delete-dialog','업무 삭제','small ghost',`data-id="${item.id}"`):''}</div></article>`).join('')||'<div class="empty"><h3>자동 추출된 업무가 없습니다.</h3><p>비정형 문서는 LLM 모드로 재검토하거나 업무를 직접 추가하세요. 검토되지 않은 문서를 업무 없음으로 처리하지 않습니다.</p></div>'}</div>
  ${editable?`<div class="action-bar"><div><strong>확인한 내용을 다음 사람에게.</strong><p>확정할 때 현재 판본과 검토 이력을 함께 보관합니다.</p></div>${button('confirm-dialog','검토 완료 · 확정하기 →','primary')}</div>`:''}</div>
  <aside class="evidence-panel"><div class="evidence-head">원문 근거 <span class="muted">SOURCE</span></div><div class="evidence-body" id="evidenceBody"><div class="evidence-placeholder"><span>▤</span><p>업무 카드의 근거를 누르면<br>원문과 위치를 볼 수 있어요.</p></div></div><div class="evidence-body"><form id="searchForm" class="search-row"><input id="searchQuery" aria-label="본문 검색" placeholder="본문 키워드 검색" maxlength="300"><button class="button small" type="submit">검색</button></form><p class="muted">예: 영수증, 주민 수요조사</p><div id="searchResults"></div></div></aside></div>`;
}
function reportView(){
  const rev=state.revision;
  if(!rev)return `<div class="empty"><h3>아직 확정된 인수인계 보고서가 없습니다.</h3><p>초안 검토에서 진행 상황·완료한 일·남은 업무·현안을 보완하고 확정하면, 인계자와 인수자가 같은 완결된 보고서를 볼 수 있습니다.</p>${state.role==='predecessor'?button('tab','초안 검토로 이동','primary','data-tab="review"'):''}</div>`;
  const link=apiUrl(`cases/${state.current}/reports/${rev.id}`);
  return `<div class="success-header"><div class="success-icon">✓</div><div><h3>전임자가 확인한 인수인계본입니다.</h3><p>인계자·인수자 공통 보고서 · ${date(rev.confirmation.created)} 확정 · 판본 ${rev.id.slice(0,8)}</p></div>${state.role==='successor'?button('accept',state.details.accepted?'확인 완료 ✓':'인수 확인','small primary'):''}</div>
  <div class="report-toolbar"><div><strong>업무 인수인계 보고서</strong><p>업무 개요 · 목표 · 추진 경과 · 실행 계획 · 공통 예산·연락망</p></div><div class="buttons"><button class="button small reader-panel-toggle" data-reader-panel="toc" aria-controls="reportToc" aria-expanded="false">☰ 목차</button><button class="button small reader-panel-toggle" data-reader-panel="chat" aria-controls="readerChatLog" aria-expanded="false">챗봇</button>${state.role==='predecessor'?button('tab','보고서 내용 보완','small','data-tab="review"'):''}<a class="button small" target="_blank" rel="noopener" href="${link}">보고서 새 창 ↗</a>${button('print-report','인쇄 / PDF 저장','small')}<a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.md`)}">MD ↓</a><a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.html`)}">HTML ↓</a><a class="button small" href="${apiUrl(`cases/${state.current}/exports/${rev.id}.docx`)}">DOCX ↓</a></div></div>
  ${state.role==='predecessor'&&state.details.current!==rev.id?'<div class="notice">새 초안이 있습니다. 아래 보고서는 양측에 전달된 기존 확정본입니다. 새 초안을 검토·확정해야 보고서가 갱신됩니다.</div>':''}
  ${reportReaderView(link)}`;
}
function readinessView(rev){
  const r=rev.readiness;if(!r?.missing_fields)return '<div class="notice green">보고서의 필수 설명란이 채워져 있습니다. 내용의 정확성과 근거를 검토한 후 확정하세요.</div>';
  return `<details class="readiness"><summary>보고서 보완: ${r.items.length}개 업무 · ${r.missing_fields}개 미기재 항목</summary><p>${esc(r.note)}</p>${r.items.map(i=>`<div class="readiness-row"><div><strong>${esc(i.title)}</strong><div class="readiness-fields">${i.missing.map(m=>`<span>${esc(m.label)} ${pencil({id:i.item_id},m.key)}</span>`).join('')}</div></div></div>`).join('')}</details>`;
}
function briefingView(){
  const b=state.briefing;if(!b)return '<div class="empty"><h3>보고서를 확정하면 일정과 연락망을 확인할 수 있습니다.</h3></div>';
  return `<div class="section-heading"><div><h2>후임자 일정·담당·연락망</h2><p class="subtitle">${esc(b.as_of)} 기준 · 최신 확정본에서 조회</p></div></div><p class="muted">${esc(b.note)}</p>
  <div class="schedule-grid">${Object.entries(b.groups).map(([name,items])=>`<section class="panel schedule-group"><h3>${esc(name)} <span>${items.length}</span></h3>${items.length?items.map(i=>`<article class="schedule-item"><h4>${esc(i.title)}</h4><p><b>일정</b> ${esc(i.due_date)||'미확인'} · <b>담당</b> ${esc(i.owner)||'미확인'}</p><p>${esc(i.next_action)||'다음 행동 확인 필요'}</p>${i.issues?`<small>현안: ${esc(i.issues)}</small>`:''}</article>`).join(''):'<p class="muted">해당 업무 없음</p>'}</section>`).join('')}</div>
  <div class="section-heading"><h2>업무별 담당·협업·연락처</h2></div><p class="muted">자료나 전임자가 기재한 연락처만 표시합니다. 협의 부서는 담당과 구분하며 빈 연락처를 추측하지 않습니다.</p><div class="table-wrap"><table><thead><tr><th>업무</th><th>담당</th><th>협의·협업</th><th>연락처</th><th>근거</th></tr></thead><tbody>${b.contacts.map(c=>`<tr><td>${esc(c.title)}</td><td>${esc(c.owner)||'미확인'}</td><td>${esc(c.collaborators)||'미기재'}</td><td>${esc(c.contacts)||'미기재'}</td><td>${['owner','collaborators','contacts'].map(k=>c.evidence[k].length?button('block',esc(labels[k])+' 근거','small',`data-id="${c.evidence[k][0].block_id}"`):c.provenance[k]==='HUMAN_ENTERED'?`<small>${esc(labels[k])}: 전임자 입력</small>`:'').join('')}</td></tr>`).join('')}</tbody></table></div>`;
}
function questionsView(){
  if(!state.revision)return '<div class="empty"><h3>확정된 보고서가 있어야 질문할 수 있습니다.</h3><p>초안이나 새로 올린 미확정 자료는 답변의 확정 사실로 사용하지 않습니다.</p></div>';
  const mode=state.qaMode||(state.config.llm_available?'llm':'local');
  return `<div class="section-heading"><div><h2>확정 보고서에 질문하기</h2><p class="subtitle">전임자가 수정·확정한 값이 과거 원문보다 우선합니다.</p></div></div><div class="panel question-panel"><form id="questionForm"><label class="form-field">질문<textarea id="questionText" maxlength="500" required placeholder="예: 생활문화 사업계획 기한은 언제인가요? 보조금 정산에서 막힌 부분은 무엇인가요?">${esc(state.questionDraft||'')}</textarea></label><label class="form-field">조회 방식<select id="questionMode">${state.config.llm_available?`<option value="llm" ${mode==='llm'?'selected':''}>Solar Pro 4 · 자연어 질의</option>`:''}<option value="local" ${mode==='local'?'selected':''}>확정본 키워드 조회 · 외부 전송 없음</option></select></label>${state.config.llm_available?`<label class="check-row"><input type="checkbox" id="questionConsent" ${state.qaConsent?'checked':''}><span>AI 질의 시 질문·공개/합성 확정본·관련 원문을 연결된 모델로 전송하는 데 동의합니다.</span></label>`:''}<button type="submit" class="button primary" ${state.qaBusy?'disabled':''}>${state.qaBusy?'보고서에서 확인 중…':'질문하기'}</button></form></div>
  <div class="question-answers">${(state.answers||[]).slice().reverse().map(a=>`<article class="panel question-answer"><h3>${esc(a.question)}</h3><p>${esc(a.message)}</p>${conversationHTML(a)}${a.paragraphs?.length?'<details><summary>답변 근거 확인</summary>':''}${a.facts.map(f=>`<div class="answer-fact"><strong>${esc(f.title)} · ${esc(f.label)}</strong><p>${esc(f.value)}</p><small>${f.provenance==='HUMAN_ENTERED'?'전임자 입력': '원문에서 추출한 보고서 기록'}${f.review_status!=='CONFIRMED'?' · 내용 검토 필요':''}${f.changed_reason?' · 사유: '+esc(f.changed_reason):''}</small>${f.evidence.map(ref=>button('block','원문 근거 ↗','small',`data-id="${ref.block_id}"`)).join('')}</div>`).join('')}${a.paragraphs?.length?'</details>':''}${a.background.length?`<details><summary>관련 원문 보충 · 확정 사실이 아님</summary><p class="muted">과거 자료일 수 있으며 위 확정값을 대체하지 않습니다.</p>${a.background.map(b=>`<div class="context-block"><strong>${esc(b.path)}</strong><p>${esc(b.text)}</p>${button('block','원문 확인','small',`data-id="${b.id}"`)}</div>`).join('')}</details>`:''}<small>${a.mode==='llm'?'Solar Pro 4':'키워드 조회'} · 판본 ${a.revision_id.slice(0,8)}${a.usage.total_tokens?' · '+a.usage.total_tokens.toLocaleString()+' 토큰':''}</small></article>`).join('')}</div>`;
}
async function askQuestion(event){
  event.preventDefault();if(state.qaBusy)return;
  const question=$('#questionText').value.trim();if(question.length<2)throw new Error('질문을 두 글자 이상 입력해 주세요.');
  const mode=$('#questionMode').value,consent=$('#questionConsent')?.checked||false;
  if(mode==='llm'&&!consent)throw new Error('AI 질의의 외부 전송 동의를 확인해 주세요.');
  const id=state.current,revision=state.revision.id;state.questionDraft=question;state.qaMode=mode;state.qaConsent=consent;state.qaBusy=true;renderCase();
  try{const answer=await api(`cases/${id}/questions`,{method:'POST',body:{question,mode,external_consent:consent,expected_revision:revision}});if(state.current===id&&state.details.confirmed===revision){state.answers=[...(state.answers||[]),answer].slice(-10);state.questionDraft='';}}
  finally{state.qaBusy=false;if(state.current===id&&state.tab==='questions')renderCase();}
}
document.addEventListener('submit',event=>{if(event.target.id==='questionForm')askQuestion(event).catch(e=>toast(e.message));});
function historyView(){const rows=state.details.history.filter(r=>state.role==='predecessor'||r.confirmed_at);return `<div class="section-heading"><h2>변경과 확정의 기록</h2><span>과거 판본은 수정되지 않습니다.</span></div><div class="panel timeline">${rows.map(r=>`<div class="history-row"><span class="history-dot"></span><div><h3>${esc(r.reason)} ${r.confirmed_at?badge('확정','green'):badge('초안','gray')}</h3><p>${date(r.created)} · ${r.actor==='SYSTEM'?'시스템':'전임자'} · 판본 ${r.id.slice(0,8)}</p><p>내용 해시 ${r.hash.slice(0,24)}…</p></div><div class="buttons">${button('history-detail','판본 보기','small',`data-id="${r.id}"`)}${r.confirmed_at?`<a class="button small" href="${apiUrl(`cases/${state.current}/exports/${r.id}.md`)}">MD ↓</a>`:''}</div></div>`).join('')||'<div class="empty">아직 변경 이력이 없습니다.</div>'}</div>`;}
async function uploadFiles(fileList){
  const files=Array.from(fileList);if(!files.length)return;
  if(state.uploading)throw new Error('이미 자료를 등록하고 있습니다. 완료 후 다시 선택해 주세요.');
  if(files.length>100)throw new Error('한 번에 100개 이하의 파일을 선택해 주세요.');
  if(files.reduce((n,f)=>n+f.size,0)>80*1024*1024)throw new Error('선택한 자료의 합계는 80MB 이하만 가능합니다.');
  const id=state.current;state.uploading=true;
  try{toast(`${files.length}개 파일을 등록하고 있습니다.`);const data=new FormData();for(const file of files)data.append('files',file,file.webkitRelativePath||file.name);
  const result=await api(`cases/${id}/documents/batch`,{method:'POST',body:data});toast(`${result.documents.filter(d=>!d.duplicate).length}개 자료 등록 · 중복 ${result.documents.filter(d=>d.duplicate).length}개`);if(state.current===id){state.tab='sources';await refresh();}}
  finally{state.uploading=false;}
}
function generateDialog(){
  if(!state.details.documents.length){toast('먼저 자료를 등록해 주세요.');state.tab='sources';renderCase();return;}
  modal('자료에서 초안 만들기','모든 문서의 블록을 조사한 뒤 업무 후보를 정리합니다.',`<label class="form-field">추출 방식<select id="extractMode"><option value="rules">로컬 규칙 추출 · 외부 전송 없음</option>${state.config.llm_available?`<option value="llm" selected>AI 문서 해석 · ${esc(modelLabel(state.config.model))}</option>`:''}</select></label><p class="muted">로컬 모드는 ‘업무:’, ‘담당:’, ‘기한:’처럼 라벨이 있는 내용을 추출합니다. 일반적인 문장·표의 의미 추출은 LLM 연결이 필요합니다.</p>${state.config.llm_available?'<label class="check-row"><input type="checkbox" id="externalConsent"><span>AI 모드에서 공개·합성 자료를 설정된 외부 모델 API로 전송하는 것에 동의합니다.</span></label>':'<div class="notice"><p>현재 LLM 미연결입니다. '+button('model','AI 모델 연결','small')+' 또는 프로젝트 전용 .env를 설정하세요.</p></div>'}${state.details.current?'<div class="notice">원문에서 새 초안을 만듭니다. 이전 수정값은 과거 판본에 보존되며 새 초안에 자동 적용되지 않습니다. 이미 전달한 확정본은 유지됩니다.</div>':''}`,button('close','취소')+button('run-generate','초안 생성 시작','primary'));
}
function pencil(item,key){return `<button type="button" class="field-pencil" data-action="edit-field" data-id="${item.id}" data-field="${key}" aria-label="${esc(labels[key])} 수정" title="${esc(labels[key])} 수정 · 근거 함께 보기"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path d="m15 5 4 4M4 20l4-1L20 7a2.8 2.8 0 0 0-4-4L4 15z" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"/></svg></button>`;}
function fieldSources(item,key){
  const sources=[],seen=new Set(),history=[];
  function add(field,label,path='',reported='',related=false){
    for(const ref of field?.evidence||[]){const identity=ref.block_id+'\n'+ref.quote;if(seen.has(identity))continue;seen.add(identity);sources.push({ref,label,path,reported,related,value:field.value});}
  }
  let f=item.fields[key];add(f,'현재 값의 원문');
  while(f?.previous){history.push({value:f.value,before:f.previous.value,reason:f.reason,changed_at:f.changed_at});f=f.previous;add(f,'수정 전 원문');}
  for(const event of [...(item.timeline||[]),...(item.supporting_records||[])].sort((a,b)=>(b.reported_at||'').localeCompare(a.reported_at||'')))add(event.fields[key],`${event.stage||'단계 미기재'}보고 · 이전 기록 포함`,event.path,event.reported_at);
  const codes=new Set((item.timeline||[]).map(e=>e.work_code).filter(Boolean));
  for(const other of state.revision.payload.items){
    if(other.id===item.id)continue;
    for(const event of other.timeline||[])if(codes.has(event.work_code))add(event.fields[key],`관련 후보 · ${event.work_code} · 아직 매칭하지 않은 자료`,event.path,event.reported_at,true);
  }
  return {sources,history};
}
function fieldEditDialog(itemId,key){
  if(state.role!=='predecessor'||state.tab!=='review')return;
  const item=state.revision.payload.items.find(i=>i.id===itemId);if(!item||!labels[key])return;
  const field=item.fields[key]||{value:''};const {sources,history}=fieldSources(item,key);
  const edit={caseId:state.current,revisionId:state.revision.id,hash:state.revision.hash,itemId,key,value:field.value||'',sources};
  const docs=state.details.documents.filter(d=>item.source_documents.includes(d.id));
  modal(`${labels[key]} 수정`,item.fields.title.value,`<div class="field-edit-layout"><section class="field-edit-form"><div class="eyebrow">확인하고 수정하기</div><div class="field-before"><span>현재 값</span><p>${esc(edit.value)||'미기재'}</p>${badge(field.provenance==='HUMAN_ENTERED'?'전임자 입력':'추출값',field.provenance==='HUMAN_ENTERED'?'green':'gray')}</div><label class="form-field" for="fieldEditValue">확인한 ${esc(labels[key])}<textarea id="fieldEditValue" maxlength="2000" rows="${['title','owner','due_date','contacts'].includes(key)?2:5}">${esc(edit.value)}</textarea></label><label class="form-field" for="fieldEditReason">확인 근거·변경 사유 (필수)<textarea id="fieldEditReason" maxlength="1000" rows="3" placeholder="예: 계획보고의 담당 부서를 대조하고 전임자에게 확인"></textarea></label><p class="field-edit-help">이 항목만 새 판본에 저장합니다. 기존 값·원문 근거·변경 사유는 이력에 보존됩니다.${state.details.confirmed?' 보고서에 반영하려면 저장 후 다시 확정하세요.':''}</p><div id="fieldEditError" role="alert"></div>${history.length?`<details class="field-history"><summary>이 항목의 수정 이력 ${history.length}건</summary>${history.map(h=>`<div class="context-block"><b>${esc(h.before)||'미기재'} → ${esc(h.value)||'미기재'}</b><p>${esc(h.reason)}<br>${date(h.changed_at)}</p></div>`).join('')}</details>`:''}</section><section class="field-edit-evidence" aria-label="관련 근거 자료"><div class="field-evidence-heading"><h3>관련 근거 자료</h3><span>${sources.length}개 인용</span></div><p class="muted">현재 값과 이전 보고를 비교하세요. 같은 관리번호의 다른 업무는 참고 후보이며 자동으로 연결하지 않습니다.</p><div class="field-source-list">${sources.map((s,i)=>{const doc=state.details.documents.find(d=>d.id===s.ref.document_revision_id);return `<details class="field-source ${s.related?'related-candidate':''}" ${i===0||s.related?'open':''}><summary><span class="field-source-label">${esc(s.label)}</span><strong>${esc(s.path||doc?.path||'원문 자료')}</strong><span class="field-source-value">${esc(s.value)||'미기재'}</span>${s.reported?`<small>보고일 ${esc(s.reported)}</small>`:''}</summary><div id="fieldSource-${i}" class="field-source-content" aria-live="polite"><p class="muted">원문을 불러오는 중입니다…</p></div></details>`;}).join('')||'<div class="field-no-source">이 항목에 직접 연결된 원문 인용이 없습니다. 아래 업무 자료를 열어 확인하거나 전임자에게 확인한 내용을 사유와 함께 기록하세요.</div>'}</div><details class="field-documents" ${sources.length?'':'open'}><summary>이 업무의 자료 전체 확인 (${docs.length})</summary>${docs.map(d=>`<div class="field-document"><strong>${esc(d.path)}</strong><button class="text-link" data-action="field-document" data-id="${d.id}">추출 본문 보기</button><a class="text-link" href="${apiUrl(`cases/${edit.caseId}/documents/${d.id}/raw`)}" download>원본 다운로드 ↓</a><div class="field-document-body" id="fieldDocument-${d.id}"></div></div>`).join('')||'<p class="muted">연결된 자료가 없는 직접 입력 업무입니다.</p>'}</details></section></div>`,button('close','취소')+button('save-field','이 항목 저장','primary'));
  state.fieldEdit=edit;$('#dialog').classList.add('field-edit-dialog');$('#fieldEditValue').focus();
  for(let i=0;i<sources.length;i++)loadFieldSource(edit,i);
}
async function loadFieldSource(edit,index){
  const entry=edit.sources[index];
  try{
    const s=await api(`cases/${edit.caseId}/blocks/${entry.ref.block_id}`);
    if(state.fieldEdit!==edit||!$('#dialog').open)return;
    $(`#fieldSource-${index}`).innerHTML=`<div class="evidence-location">${esc(s.location)} · 자료 판본 ${esc(s.doc_id.slice(0,8))}</div><blockquote class="quote">${esc(entry.ref.quote)}</blockquote><details class="field-context"><summary>주변 본문</summary>${s.neighbors.map(n=>`<div class="context-block ${n.id===s.id?'quoted-block':''}"><small>${esc(n.location)}</small>${esc(n.text)}</div>`).join('')}</details><div class="field-source-actions"><a class="text-link" href="${apiUrl(`cases/${edit.caseId}/documents/${s.doc_id}/raw`)}" download>원본 다운로드 ↓</a></div>`;
  }catch(error){if(state.fieldEdit===edit&&$('#dialog').open)$(`#fieldSource-${index}`).innerHTML=`<p class="field-load-error">${esc(error.message)}</p>${button('retry-field-source','다시 불러오기','small',`data-index="${index}"`)}`;}
}
async function fieldDocument(el){
  const edit=state.fieldEdit;if(!edit)return;
  const blocks=await api(`cases/${edit.caseId}/documents/${el.dataset.id}/blocks`);
  if(state.fieldEdit!==edit||!$('#dialog').open)return;
  $(`#fieldDocument-${el.dataset.id}`).innerHTML=blocks.map(b=>`<div class="context-block"><small>${esc(b.location)}</small>${esc(b.text)}</div>`).join('')||'<p class="muted">추출된 본문이 없습니다.</p>';
}
async function saveField(){
  const edit=state.fieldEdit;if(!edit)return;
  const value=$('#fieldEditValue').value.trim(),reason=$('#fieldEditReason').value.trim();
  const fail=message=>{$('#fieldEditError').textContent=message;};
  if(edit.key==='title'&&!value){fail('업무명은 비워 둘 수 없습니다.');$('#fieldEditValue').focus();return;}
  if(!reason){fail('확인 근거·변경 사유를 입력해 주세요.');$('#fieldEditReason').focus();return;}
  try{
    await api(`cases/${edit.caseId}/revisions/${edit.revisionId}/items/${edit.itemId}`,{method:'PATCH',body:{expected_hash:edit.hash,fields:{[edit.key]:value},reason}});
  }catch(error){if(state.fieldEdit===edit)fail(error.message);return;}
  if(state.fieldEdit!==edit)return;
  closeDialog();await refresh();toast(`${labels[edit.key]} 항목을 저장했습니다.${state.details.confirmed?' 보고서 반영은 다시 확정해 주세요.':''}`);
}
function deleteDialog(itemId){const item=state.revision.payload.items.find(i=>i.id===itemId);modal('업무 삭제',item.fields.title.value,`<p>초안에서 이 업무를 제외합니다. 이전 판본은 보존됩니다.</p><label class="form-field">삭제 사유 (필수)<input id="editReason" maxlength="1000"></label>`,button('close','취소')+button('delete-item','업무 삭제','danger',`data-id="${itemId}"`));}

function editDialog(itemId){
  const item=state.revision.payload.items.find(i=>i.id===itemId);modal(item?'업무 내용 수정':'업무 직접 추가','변경된 값은 전임자 입력으로 기록하고, 이전 근거는 수정 이력에 보존합니다.',`<div class="form-grid">${Object.entries(labels).map(([key,label])=>`<label class="form-field ${['title','next_action','notes','completed_work','remaining_work','issues','collaborators','contacts'].includes(key)?'wide':''}">${label}${!['title','status','owner','due_date'].includes(key)?`<textarea id="edit_${key}" maxlength="2000">${esc(item?.fields[key]?.value||'')}</textarea>`:`<input id="edit_${key}" maxlength="2000" value="${esc(item?.fields[key]?.value||'')}" placeholder="${key==='due_date'?'예: 2026-11-27 또는 매월 5일':'확인된 내용을 입력하세요'}">`}</label>`).join('')}<label class="form-field wide">변경 사유 (필수)<input id="editReason" maxlength="1000" placeholder="예: 전임자가 최종 제출 일정을 확인"></label></div>`,(item?button('delete-item','업무 삭제','danger small',`data-id="${itemId}"`):'')+button('close','취소')+button('save-item','새 판본으로 저장','primary',`data-id="${itemId||'new'}"`));
}
async function saveItem(itemId,deleted=false){
  const reason=$('#editReason').value.trim();if(!reason)throw new Error('변경 사유를 입력해 주세요.');
  const item=state.revision.payload.items.find(i=>i.id===itemId), fields={};
  if(!deleted)for(const key of Object.keys(labels)){const value=$('#edit_'+key).value.trim();if(!item||value!==(item.fields[key]?.value||''))fields[key]=value;}
  if(!deleted&&!Object.keys(fields).length)throw new Error('변경할 내용을 입력해 주세요.');
  await api(`cases/${state.current}/revisions/${state.revision.id}/items/${itemId}`,{method:'PATCH',body:{expected_hash:state.revision.hash,fields,reason,delete:deleted}});closeDialog();toast('변경 내용을 새 판본으로 저장했습니다.');await refresh();
}
async function showEvidence(itemId,key){
  const item=state.revision.payload.items.find(i=>i.id===itemId);const field=item.fields[key];
  let refs=field.evidence;let history='';let previous=field;
  while(previous.previous){history+=`<div class="notice green"><div><strong>전임자 입력: ${esc(previous.value)}</strong><p>이전 값: ${esc(previous.previous.value)}<br>사유: ${esc(previous.reason)}<br>${date(previous.changed_at)}</p></div></div>`;previous=previous.previous;refs=refs.concat(previous.evidence);}
  if(!refs.length){$('#evidenceBody').innerHTML=history||'<p>원문 근거가 없는 전임자 입력 또는 미확인 항목입니다.</p>';return;}
  const source=await api(`cases/${state.current}/blocks/${refs[0].block_id}`);
  $('#evidenceBody').innerHTML=history+sourceView(source,refs[0].quote)+refs.slice(1).map(ref=>`<button class="search-result" data-action="block" data-id="${ref.block_id}">${esc(ref.quote)} <span>↗</span></button>`).join('');
  if(innerWidth<850)$('#evidenceBody').scrollIntoView({behavior:'smooth',block:'center'});
}
function sourceView(source,quote){return `<div class="evidence-source">${esc(source.path)}</div><div class="evidence-location">${esc(source.location)} · 판본 ${source.doc_id.slice(0,8)}</div><blockquote class="quote">${esc(quote||source.text)}</blockquote><a class="text-link" href="${apiUrl(`cases/${state.current}/documents/${source.doc_id}/raw`)}">원본 다운로드 ↓</a><div class="source-hash">원문 SHA-256<br>${source.source_sha}</div><details><summary class="text-link">주변 원문 함께 보기</summary>${source.neighbors.map(b=>`<div class="context-block"><small>${esc(b.location)}</small>${esc(b.text)}</div>`).join('')}</details>`;}
async function showBlock(id){const source=await api(`cases/${state.current}/blocks/${id}`);if($('#evidenceBody'))$('#evidenceBody').innerHTML=sourceView(source);else modal('원문 근거',source.path,sourceView(source),button('close','닫기'));}
function matchDialog(id){
 const source=state.revision.payload.items.find(i=>i.id===id);const targets=state.revision.payload.items.filter(i=>i.id!==id);
 modal('담당자 확인 후 업무 매칭','명칭이 다른 보고서가 같은 업무인지 원문과 담당자를 확인해 연결합니다.',`<p><b>연결할 업무:</b> ${esc(source.fields.title.value)}</p><p class="muted">${source.timeline?.map(e=>esc(e.path)+' · '+esc(e.work_code||'관리번호 미기재')).join('<br>')||''}</p><label class="form-field">합칠 기준 업무<select id="matchTarget">${targets.map(t=>`<option value="${t.id}">${esc(t.fields.title.value)} · ${esc(t.fields.owner.value||'담당 미확인')} · ${esc(t.timeline?.[0]?.work_code||'')}</option>`).join('')}</select></label><label class="form-field">확인한 담당 부서<input id="matchOwner" maxlength="200" placeholder="예: 디지털지원팀"></label><label class="form-field">확인 근거·매칭 사유<input id="matchReason" maxlength="1000" placeholder="예: HB-004 동일 사업임을 전임자에게 확인"></label><label class="check-row"><input type="checkbox" id="matchCheck"><span>담당자를 확인했고 같은 업무임을 확인했습니다. 기준 업무명으로 연결하고 각 보고 이력은 보존합니다.</span></label>`,button('close','취소')+button('save-match','확인 후 새 판본에 매칭','primary',`data-id="${id}"`));
}
function confirmationDialog(){const rev=state.revision;modal('인수인계본 확정','지금 보고 있는 판본을 후임자에게 전달합니다.',`<p>총 <strong>${rev.payload.items.length}개 업무</strong>를 판본 <strong>${rev.id.slice(0,8)}</strong>로 확정합니다.</p><div class="notice"><p>문서를 확정해도 미확인 사실이 자동으로 검증 완료되지는 않습니다. 남은 주의사항과 원문 근거를 함께 전달합니다.</p></div>${rev.readiness?.missing_fields?`<div class="notice"><p>보고서에 ${rev.readiness.missing_fields}개 항목이 미기재입니다. ${esc(rev.readiness.note)} 확인 필요 상태로 전달할 수 있습니다.</p></div>`:''}${rev.warnings.length?`<ul class="warning-list">${rev.warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul>`:''}<label class="check-row"><input type="checkbox" id="confirmCheck"><span>수정 내용과 남은 확인 필요 사항을 확인했으며, 이 판본을 인수인계본으로 전달합니다.</span></label>`,button('close','더 검토하기')+button('do-confirm','이 판본 확정','primary'));}
function helpDialog(){modal('업무바통 시작 가이드','자료부터 확정본까지 네 단계로 이어집니다.',`<div class="support-list"><div><b>01. 자료 모으기</b>인수인계함을 만들고 ZIP 또는 문서를 올립니다. 샘플에는 4개 업무의 계획·착수·중간·완료 보고서 11개가 들어 있습니다.</div><div><b>02. 초안과 근거 확인하기</b>초안을 생성하고 카드의 ‘원문 근거’를 확인하세요. ‘영수증’처럼 파일명에 없는 본문 표현도 검색할 수 있습니다.</div><div><b>03. 수정하고 확정하기</b>각 항목 옆 연필을 눌러 원문과 확인한 값을 함께 보며 수정합니다. 명칭이 다른 예약 개선 보고서는 담당자 확인 후 같은 업무로 매칭합니다. 검토가 끝나면 확정합니다.</div><div><b>04. 후임자에게 전달하기</b>오른쪽 위 역할을 후임자로 바꾸면 확정본이 먼저 보입니다. 인수 확인과 MD·HTML 다운로드를 할 수 있습니다.</div><div><b>지원 범위</b>이미지 OCR·기관 인증·전자서명·의미검색은 포함하지 않습니다. 로컬 추출과 LLM 추출은 화면에서 구분됩니다.</div></div>`,button('close','시작하기','primary'));}
function loginDialog(){modal('워크스페이스 접속','관리자가 제공한 접속 코드를 입력하세요. 역할 선택과 별도의 공유 접속 보호입니다.',`<label class="form-field">접속 코드<input type="password" id="accessToken" autocomplete="current-password"></label><p><a class="text-link" href="guide" target="_blank" rel="noopener">사용법·샘플·체험 자료는 로그인 없이 볼 수 있습니다 ↗</a></p>`,button('login','접속하기','primary'));}
function modelDialog(){modal('AI 모델 연결','이 프로젝트 전용 Upstage 키로 비정형 문서의 업무를 추출합니다.',`${state.config.llm_available?'<div class="notice green">현재 '+esc(modelLabel(state.config.model))+'가 연결되어 있습니다. 키를 다시 입력하지 않아도 AI 분석을 사용할 수 있습니다.</div>':''}<label class="form-field">모델<select id="modelName"><option value="solar-pro4">Solar Pro 4</option><option value="solar-mini4">Solar Mini 4</option></select></label><label class="form-field">프로젝트 전용 API 키<input type="password" id="modelKey" autocomplete="off" placeholder="Upstage API 키"></label><div class="notice"><p>‘연결 시험’은 짧은 합성 문장만 Upstage에 전송하며 API 사용료가 발생할 수 있습니다. 기존 자료는 전송하지 않습니다. 키는 서버 메모리에만 보관되며, 이 워크스페이스 사용자들이 연결된 모델을 공유합니다.</p></div><p class="muted">자료를 AI로 분석할 때 공개·합성 자료 전송에 별도로 동의합니다. 재시작 후에는 다시 연결하거나 프로젝트 전용 .env를 설정하세요.</p>`,button('close','취소')+button('connect-model','연결 시험','primary'));}
const actions={
  'close':closeDialog,'home':async()=>{state.cases=await api('cases');renderHome();},'new-case':caseDialog,'help':helpDialog,
  'open-report':async()=>{state.tab='report';await refresh();},'print-report':()=>$('#reportFrame').contentWindow.print(),
  'open-case':el=>openCase(el.dataset.id),'tab':el=>{state.tab=el.dataset.tab;return refresh();},
  'create-case':async()=>{const title=$('#caseTitle').value.trim();if(!title)throw new Error('인수인계 이름을 입력해 주세요.');const c=await createCase(title,$('#predecessor').value,$('#successor').value);closeDialog();await openCase(c.id,'sources');},
  'start-demo':async()=>{toast('계획·착수·중간 보고서 샘플로 인수인계함을 만들고 있습니다.');const ai=state.config.llm_available;const c=await createCase(ai?'4개 업무 흐름 · Solar Pro 4 체험':'4개 업무 흐름 · 샘플','김전임 (가상)','이후임 (가상)');await api(`cases/${c.id}/practice-demo`,{method:'POST'});await api(`cases/${c.id}/generate`,{method:'POST',body:{mode:ai?'llm':'rules',external_consent:ai,request_id:crypto.randomUUID()}});await openCase(c.id,'review');},
  'upload':()=>$('#fileInput').click(),'upload-folder':()=>$('#folderInput').click(),'sample':async()=>{await api(`cases/${state.current}/practice-demo`,{method:'POST'});toast('단계별 보고·실무 기준·예산·연락망·증빙 자료 15개를 등록했습니다. 초안을 생성해 보세요.');await refresh();},
  'match':el=>matchDialog(el.dataset.id),
  'save-match':async el=>{if(!$('#matchCheck').checked)throw Error('동일 업무·담당자 확인에 체크해 주세요.');await api(`cases/${state.current}/revisions/${state.revision.id}/match`,{method:'POST',body:{expected_hash:state.revision.hash,source_id:el.dataset.id,target_id:$('#matchTarget').value,owner:$('#matchOwner').value,reason:$('#matchReason').value}});closeDialog();await refresh();toast('보고 이력을 연결한 새 판본을 저장했습니다.');},
  'generate':generateDialog,'run-generate':async()=>{await api(`cases/${state.current}/generate`,{method:'POST',body:{mode:$('#extractMode').value,external_consent:$('#externalConsent')?.checked||false,request_id:crypto.randomUUID()}});closeDialog();state.tab='review';await refresh();},
  'retry':async el=>{await api(`cases/${state.current}/jobs/${el.dataset.id}/retry`,{method:'POST'});await refresh();},
  'edit-field':el=>fieldEditDialog(el.dataset.id,el.dataset.field),'save-field':saveField,'retry-field-source':el=>loadFieldSource(state.fieldEdit,Number(el.dataset.index)),'field-document':fieldDocument,'delete-dialog':el=>deleteDialog(el.dataset.id),'add-item':()=>editDialog('new'),'save-item':el=>saveItem(el.dataset.id),'delete-item':el=>saveItem(el.dataset.id,true),
  'evidence':el=>showEvidence(el.dataset.id,el.dataset.field),'block':el=>showBlock(el.dataset.id),
  'document':async el=>{const blocks=await api(`cases/${state.current}/documents/${el.dataset.id}/blocks`);const doc=state.details.documents.find(d=>d.id===el.dataset.id);modal('추출한 원문 본문',doc.path,blocks.length?blocks.map(b=>`<div class="context-block"><small>${esc(b.location)}</small>${esc(b.text)}</div>`).join(''):'<p>추출된 본문이 없습니다. 자료의 처리 상태를 확인하세요.</p>',button('close','닫기'));},
  'confirm-dialog':confirmationDialog,'do-confirm':async()=>{if(!$('#confirmCheck').checked)throw new Error('전달할 내용과 주의사항 확인에 체크해 주세요.');await api(`cases/${state.current}/revisions/${state.revision.id}/confirm`,{method:'POST',body:{expected_hash:state.revision.hash,acknowledge_warnings:true}});closeDialog();toast('인수인계본을 확정했습니다. 후임자 역할로 확인해 보세요.');state.tab='report';await refresh();},
  'accept':async()=>{await api(`cases/${state.current}/accept`,{method:'POST',body:{expected_hash:state.revision.hash}});toast('후임자 확인을 기록했습니다.');await refresh();},
  'warnings':()=>modal('확인 필요 사항','문서 확정 이후에도 이 항목은 함께 전달됩니다.',`<ul class="warning-list">${state.revision.warnings.map(w=>`<li>${esc(w)}</li>`).join('')}</ul>`,button('close','확인')),
  'history-detail':async el=>{const rev=await api(`cases/${state.current}/revisions/${el.dataset.id}`);modal('보관된 판본',`${date(rev.created)} · ${rev.id.slice(0,8)} · ${rev.reason}`,rev.payload.items.map(i=>`<div class="context-block"><h3>${esc(i.fields.title.value)}</h3>${Object.entries(i.fields).filter(([k])=>k!=='title').map(([k,f])=>`<p>${labels[k]}: ${esc(f.value)||'미확인'} <small>${esc(f.provenance)} / ${esc(f.review_status)}</small></p>`).join('')}</div>`).join(''),button('close','닫기'));},
  'login':async()=>{await api('login',{method:'POST',body:{token:$('#accessToken').value}});closeDialog();await init();},
  'model':modelDialog,'connect-model':async()=>{toast('합성 문장으로 모델 연결을 시험하고 있습니다.');await api('model',{method:'POST',body:{key:$('#modelKey').value,model:$('#modelName').value}});$('#modelKey').value='';closeDialog();state.config=await api('config');$('#modeFooter').textContent=`LLM 연결 · ${modelLabel(state.config.model)}`;toast('모델 연결을 확인했습니다. 초안 생성에서 AI 문서 해석을 선택하세요.');},
  'switch-predecessor':async()=>{state.role='predecessor';localStorage.setItem('handover-role',state.role);await init();}
};
document.addEventListener('click',async event=>{const el=event.target.closest('[data-action]');if(!el||!actions[el.dataset.action])return;event.preventDefault();const disabled=el.disabled;el.disabled=true;try{await actions[el.dataset.action](el);}catch(e){toast(e.message);}finally{el.disabled=disabled;}});
document.addEventListener('submit',async event=>{if(event.target.id!=='searchForm')return;event.preventDefault();try{const result=await api(`cases/${state.current}/search?q=${encodeURIComponent($('#searchQuery').value)}`);$('#searchResults').innerHTML=result.results.length?result.results.map(b=>`<button class="search-result" data-action="block" data-id="${b.id}">${esc(b.path)} <span>↗</span><p>${esc(b.text)}</p></button>`).join(''):'<p class="muted">일치하는 본문을 찾지 못했습니다. 다른 키워드로 검색해 보세요.</p>';}catch(e){toast(e.message);}});
$('#homeButton').addEventListener('click',()=>actions.home().catch(e=>toast(e.message)));$('#helpButton').addEventListener('click',helpDialog);$('#newCaseSmall').addEventListener('click',caseDialog);
$('#modelButton').addEventListener('click',modelDialog);
$('#fileInput').addEventListener('change',async e=>{if(e.target.files.length)try{await uploadFiles(e.target.files);}catch(err){toast(err.message);}e.target.value='';});
$('#folderInput').addEventListener('change',async e=>{if(e.target.files.length)try{await uploadFiles(e.target.files);}catch(err){toast(err.message);}e.target.value='';});
$('#roleSelect').addEventListener('change',async e=>{state.role=e.target.value;localStorage.setItem('handover-role',state.role);$('#avatar').textContent=state.role==='predecessor'?'전':'후';state.tab=state.details?.confirmed?'report':state.role==='successor'?'report':'review';try{if(state.current)await refresh();else renderHome();}catch(err){toast(err.message);}});
window.addEventListener('hashchange',()=>{
  const id=location.hash.slice(1);
  if(id===state.current||(!id&&!state.current))return;
  if(id&&state.cases.some(c=>c.id===id))openCase(id).catch(e=>toast(e.message));
  else if(!id)actions.home().catch(e=>toast(e.message));
  else toast('이 인수인계함을 찾을 수 없습니다. 목록을 새로 고친 뒤 확인해 주세요.');
});
$('#dialog').addEventListener('close',()=>{if(!$('#dialog').open){state.fieldEdit=null;$('#dialog').classList.remove('field-edit-dialog');}});
init();

let budgetBusy=false;
async function refreshBudget(){
 if(budgetBusy||document.hidden)return;budgetBusy=true;
 try{const response=await fetch(apiUrl('budget'));if(!response.ok)throw new Error();const b=await response.json();state.budget=b;$('#budgetButton span').textContent=b.available&&b.unknown_calls?`추정 잔액 · 미확인 ${b.unknown_calls}건`:'Solar · 추정 잔액';$('#budgetBalance').textContent=b.available?`$${b.remaining_usd.toFixed(4)} / $${b.budget_usd.toFixed(0)}`:'모델 미연결';$('#budgetButton').title=b.available?b.note:'Solar 연결 후 표시됩니다.';}
 catch(e){$('#budgetBalance').textContent='잔액 확인 불가';state.budget=null;}finally{budgetBusy=false;}
}
function budgetDialog(){const b=state.budget;if(!b){toast('사용량을 불러오지 못했습니다. 잠시 후 다시 확인하세요.');refreshBudget();return;}if(!b.available){toast('Solar 모델을 먼저 연결하세요.');return;}modal('Solar 전용 키 · 사용량','이 앱의 기록으로 계산한 추정 잔액입니다.',`<div class="budget-summary"><strong>$${b.remaining_usd.toFixed(4)}</strong><p>$${b.budget_usd.toFixed(2)} 기준 · 기록된 추정 사용액 $${b.used_usd.toFixed(6)}</p></div><p>집계 시작: ${esc(new Date(b.tracked_since).toLocaleString('ko-KR'))}</p><p>호출 ${b.calls}회 · 사용량 미확인 ${b.unknown_calls}회</p><p>입력 ${b.prompt_tokens.toLocaleString()}토큰 (캐시 ${b.cached_tokens.toLocaleString()}) · 출력 ${b.completion_tokens.toLocaleString()}토큰</p><p class="notice">${esc(b.note)} 이 표시는 API의 결제 한도를 설정하거나 차단하는 기능이 아닙니다.</p><p>Solar Pro 4 정가: 100만 토큰당 입력 $0.30 · 캐시 $0.06 · 출력 $1.20</p><div class="buttons"><a class="button" href="${esc(b.console_url)}" target="_blank" rel="noopener">실제 잔액 · Upstage 콘솔 ↗</a><a class="button" href="${esc(b.pricing_url)}" target="_blank" rel="noopener">공식 요금표 ↗</a></div>`,button('close','닫기'));}
document.addEventListener('click',e=>{if(e.target.closest('#budgetButton'))budgetDialog();});
setInterval(refreshBudget,30000);
document.addEventListener('visibilitychange',()=>{if(!document.hidden)refreshBudget();});
